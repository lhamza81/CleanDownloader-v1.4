package com.example.cleanbrowser.browser

/** Runs inside the page: finds MP4/M3U8 links in <video>, <source>, links and og:video tags. */
object VideoScanner {
    /**
     * Installed in every page. Reports a video the moment it is added to the page or starts loading,
     * instead of waiting for the next scan. Safe to run more than once.
     */
    const val WATCHER_JS = """
    (function(){
      if (window.__cdWatch) return;
      window.__cdWatch = true;
      function rep(u){ try{ if(u && window.CDBridge) CDBridge.found(new URL(u, location.href).href); }catch(e){} }
      function check(v){ rep(v.currentSrc); rep(v.src); rep(v.getAttribute && v.getAttribute('data-src')); }
      ['loadstart','loadedmetadata','play','playing'].forEach(function(ev){
        document.addEventListener(ev, function(e){
          var t = e.target;
          if(t && t.tagName === 'VIDEO') check(t);
          else if(t && t.tagName === 'SOURCE') rep(t.src);
        }, true);
      });
      try{
        new MutationObserver(function(muts){
          muts.forEach(function(m){
            if(!m.addedNodes) return;
            m.addedNodes.forEach(function(n){
              if(n.nodeType !== 1) return;
              if(n.tagName === 'VIDEO') check(n);
              else if(n.tagName === 'SOURCE') rep(n.src);
              else if(n.querySelectorAll) n.querySelectorAll('video,source').forEach(function(x){
                if(x.tagName === 'VIDEO') check(x); else rep(x.src);
              });
            });
          });
        }).observe(document.documentElement, {childList:true, subtree:true});
      }catch(e){}
      document.querySelectorAll('video').forEach(check);
    })();
    """

    const val JS = """
    (function(){
      var out = {};
      function ok(p){ p = p.toLowerCase(); return p.endsWith('.mp4') || p.endsWith('.m3u8'); }
      function add(u){
        try{
          if(!u) return;
          var a = new URL(u, location.href);
          if(a.protocol !== 'http:' && a.protocol !== 'https:') return;
          if(ok(a.pathname)){ out[a.href] = 1; return; }
          a.searchParams.forEach(function(v){
            if(/^https?:\/\//i.test(v)){ try{ if(ok(new URL(v).pathname)) out[v] = 1; }catch(e){} }
          });
        }catch(e){}
      }
      document.querySelectorAll('video').forEach(function(v){
        add(v.currentSrc); add(v.src); add(v.getAttribute('data-src'));
      });
      document.querySelectorAll('source').forEach(function(s){ add(s.src); add(s.getAttribute('data-src')); });
      document.querySelectorAll('a[href]').forEach(function(a){ add(a.href); });
      document.querySelectorAll('meta[property^="og:video"], meta[name^="twitter:player:stream"]').forEach(function(m){ add(m.content); });
      return JSON.stringify(Object.keys(out));
    })()
    """
}
