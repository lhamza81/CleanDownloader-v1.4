package com.example.cleanbrowser

/** Lets the app skip the "Welcome back" screen once, e.g. when it opens a picker or another app on purpose. */
object AppLock {
    @Volatile
    var skipNext = false
}
